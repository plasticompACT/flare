
import { verifySignatureAppRouter } from "@upstash/qstash/nextjs";
import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/app/lib/supabaseAdmin";

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;

async function sendTelegram(chatId: string, text: string) {
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: "Markdown" }),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`Telegram send failed: ${res.status} ${t}`);
  }
}

async function handler(req: Request) {
  const { ritualId, participantId, day } = await req.json();

  // find participant & prompt text
  const { data: participant } = await supabaseAdmin.from("participants").select("*").eq("id", participantId).single();
  const { data: prompts } = await supabaseAdmin.from("prompt_sets").select("*").eq("is_default", true).single();

  const promptText = (prompts?.prompts?.[String(day)]) || `Day ${day}`;
  const title = promptText.split(" — ")[0] || `Day ${day}`;
  const body = promptText.split(" — ")[1] || "";
  const message = `**Day ${day} — ${title}**\n${body}`;

  if (participant?.messenger === "telegram" && participant?.messenger_user_id) {
    await sendTelegram(participant.messenger_user_id, message);
  }

  // mark delivered
  await supabaseAdmin.from("deliveries").update({
    delivered_at: new Date().toISOString(),
    status: "delivered"
  }).match({ ritual_id: ritualId, participant_id: participantId, day });

  return NextResponse.json({ ok: true });
}

export const POST = verifySignatureAppRouter(handler);
