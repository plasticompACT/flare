
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { supabaseAdmin } from "@/app/lib/supabaseAdmin";
import { DateTime } from "luxon";

const schema = z.object({
  participants: z.array(z.object({
    displayName: z.string().min(1),
    timezone: z.string().min(1),
    messenger: z.enum(["telegram","pwa"])
  })).length(2),
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  hour: z.number().int().min(0).max(23),
  minute: z.number().int().min(0).max(59),
});

function token() {
  return Math.random().toString(36).slice(2,10);
}

async function scheduleOneTime(body: any, notBeforeUnixSeconds: number) {
  // Using QStash /v2/publish with Upstash-Not-Before header
  const res = await fetch(`${process.env.QSTASH_URL || "https://qstash.upstash.io"}/v2/publish/${process.env.PUBLIC_BASE_URL}/api/webhooks/qstash`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${process.env.QSTASH_TOKEN}`,
      "Content-Type": "application/json",
      "Upstash-Method": "POST",
      "Upstash-Not-Before": String(notBeforeUnixSeconds),
      "Upstash-Retries": "5"
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`QStash publish failed: ${res.status} ${t}`);
  }
  const data = await res.json();
  return data.messageId as string;
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { participants, startDate, hour, minute } = parsed.data;

  // create ritual
  const { data: ritual, error: rErr } = await supabaseAdmin
    .from("rituals")
    .insert({
      starts_on: startDate,
      local_send_hour: hour,
      local_send_min: minute,
      status: "active",
    }).select().single();
  if (rErr) return NextResponse.json({ error: rErr.message }, { status: 500 });

  // create participants with join tokens
  const toInsert = participants.map((p: any) => ({
    ritual_id: ritual.id,
    display_name: p.displayName,
    timezone: p.timezone,
    messenger: p.messenger,
    join_token: token(),
  }));
  const { data: parts, error: pErr } = await supabaseAdmin.from("participants").insert(toInsert).select();
  if (pErr) return NextResponse.json({ error: pErr.message }, { status: 500 });

  // schedule 11 prompts per participant (using notBefore)
  // Each day at participant's local time
  for (const part of parts) {
    for (let day = 1; day <= 11; day++) {
      const dt = DateTime.fromISO(startDate, { zone: part.timezone })
        .set({ hour, minute, second: 0, millisecond: 0 })
        .plus({ days: day - 1 })
        .toUTC();
      const notBefore = Math.floor(dt.toSeconds());
      const messageId = await scheduleOneTime({ ritualId: ritual.id, participantId: part.id, day }, notBefore);
      await supabaseAdmin.from("deliveries").insert({
        ritual_id: ritual.id,
        participant_id: part.id,
        day,
        scheduled_at: dt.toISO(),
        qstash_message_id: messageId,
      });
    }
  }

  const inviteLink = `${process.env.PUBLIC_BASE_URL}/join/${parts[0].join_token}`; // share either token; both work

  return NextResponse.json({ ritualId: ritual.id, inviteLink });
}
