
import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/app/lib/supabaseAdmin";

export async function POST(req: NextRequest) {
  const { token, telegramChatId } = await req.json();
  if (!token || !telegramChatId) {
    return NextResponse.json({ error: "Missing token or telegramChatId" }, { status: 400 });
  }
  const { data: participant, error } = await supabaseAdmin.from("participants").update({
    messenger_user_id: String(telegramChatId),
    joined_at: new Date().toISOString()
  }).eq("join_token", token).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  if (!participant) return NextResponse.json({ error: "Invalid token" }, { status: 404 });
  return NextResponse.json({ ok: true, participant });
}
