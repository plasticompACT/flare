
create extension if not exists pgcrypto;
create type ritual_status as enum ('draft','active','completed','canceled');
create type tz_mode as enum ('per_participant','single');
create type delivery_status as enum ('scheduled','delivered','skipped','failed');

create table if not exists rituals (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  starts_on date not null,
  local_send_hour int not null,
  local_send_min int not null,
  owner_email text,
  status ritual_status not null default 'active',
  tz_mode tz_mode not null default 'per_participant'
);

create table if not exists participants (
  id uuid primary key default gen_random_uuid(),
  ritual_id uuid not null references rituals(id) on delete cascade,
  display_name text not null,
  timezone text not null,
  messenger text not null check (messenger in ('telegram','pwa')),
  messenger_user_id text,
  join_token text unique,
  joined_at timestamptz,
  nudges_opt_in boolean not null default true
);

create table if not exists prompt_sets (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  prompts jsonb not null,
  is_default boolean not null default false
);

create table if not exists deliveries (
  id uuid primary key default gen_random_uuid(),
  ritual_id uuid not null references rituals(id) on delete cascade,
  participant_id uuid not null references participants(id) on delete cascade,
  day smallint not null check (day between 1 and 11),
  scheduled_at timestamptz not null,
  delivered_at timestamptz,
  status delivery_status not null default 'scheduled',
  qstash_message_id text
);

create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  type text not null,
  payload jsonb not null,
  created_at timestamptz not null default now()
);

alter table rituals enable row level security;
alter table participants enable row level security;
alter table deliveries enable row level security;
alter table prompt_sets enable row level security;
alter table events enable row level security;

create policy service_all_rituals on rituals for all using (auth.role() = 'service_role') with check (auth.role() = 'service_role');
create policy service_all_participants on participants for all using (auth.role() = 'service_role') with check (auth.role() = 'service_role');
create policy service_all_deliveries on deliveries for all using (auth.role() = 'service_role') with check (auth.role() = 'service_role');
create policy service_all_prompt_sets on prompt_sets for all using (auth.role() = 'service_role') with check (auth.role() = 'service_role');
create policy service_all_events on events for all using (auth.role() = 'service_role') with check (auth.role() = 'service_role');
