
insert into prompt_sets (name, prompts, is_default) values
('Default 11', '{
  "1": "Spark — Describe the moment we first felt electric.",
  "2": "Echo — Something you said that still rings in me.",
  "3": "Horizon — A future scene I can almost see.",
  "4": "Gravity — What pulls me back to you when I drift.",
  "5": "Bridge — A small way we meet in the middle.",
  "6": "Quiet — What your silence sounds like to me.",
  "7": "Storm — A hard thing we weathered (as weather).",
  "8": "Mirror — How loving you changes my reflection.",
  "9": "Orbit — The rituals we circle, night after night.",
  "10": "Ember — What glows after the fire.",
  "11": "Flare — A wish we release into the dark."
}', true)
on conflict do nothing;
