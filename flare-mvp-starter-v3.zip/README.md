# Flare — MVP v3 (Microsite + Telegram + Real Scheduling)

This version adds:
- **Supabase** inserts (ritual + participants + tokens)
- **Telegram** `/start <token>` join linking
- **QStash** one-time scheduling (11 days × 2 people) using `notBefore` (Unix seconds)
- **Signature verification** for QStash webhook
- **Coral accent** styling

## What you’ll do (non‑technical)
1) Put this repo on **GitHub**.
2) **Vercel** → import project (root: `apps/microsite`).
3) **Supabase** → run SQL in `infra/supabase/migrations/000_init.sql` and seed prompts (011 file).
4) **Environment Variables** on Vercel (Project → Settings → Env):
   - `PUBLIC_BASE_URL` = your deployed URL, e.g. `https://flare.vercel.app`
   - From Supabase Settings → API copy:
     - `SUPABASE_URL`
     - `SUPABASE_ANON_KEY`
     - `SUPABASE_SERVICE_ROLE_KEY`
   - From QStash console: 
     - `QSTASH_TOKEN`
     - `QSTASH_CURRENT_SIGNING_KEY`
     - `QSTASH_NEXT_SIGNING_KEY` (even if empty in console, add later when rotated)
   - From @BotFather:
     - `TELEGRAM_BOT_TOKEN`
5) Redeploy on Vercel.
6) Set Telegram webhook (open in browser, replace placeholders):
   `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook?url=<PUBLIC_BASE_URL>/api/webhooks/telegram`
7) Test: in Telegram, DM your bot: `/start` (you should see welcome).

## Using the app
- Go to your site → fill Partner names, pick a start date and time → **Create ritual**.
- It returns an invite link `.../join/<token>` — share it to each partner.
- Partner taps the link; it opens Telegram with `/start <token>` OR copy-paste the token after `/start`.
- The bot links them and confirms the next send time.
- QStash will call your `/api/webhooks/qstash` **at the exact times** for each partner/day.

## References (for devs helping you)
- QStash **publish** with `Upstash-Not-Before` (single future time): upstash docs “Publish a Message” (v2) → headers `Upstash-Not-Before` unix seconds. 
- QStash **verify signature** in Next.js App Router with `verifySignatureAppRouter`.
- QStash **create schedule** (cron) exists but we don’t need it for one-off sends.

